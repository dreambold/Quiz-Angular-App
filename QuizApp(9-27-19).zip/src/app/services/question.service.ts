import { Injectable } from "@angular/core";
import {
  HttpClient,
  HttpErrorResponse,
  HttpParams
} from "@angular/common/http";

import { Observable, throwError } from "rxjs";
import { map, catchError } from "rxjs/operators";

import { AppConstants } from "../constants";

@Injectable({
  providedIn: "root"
})
export class QuestionService {
  questions: any[];
  _baseURL: string;
  constructor(private http: HttpClient) {
    this._baseURL = AppConstants.baseURL;
  }

  getAll(): Observable<any[]> {
    return this.http.get(`${this._baseURL}questions`).pipe(
      map(res => {
        this.questions = res["data"];
        return this.questions;
      }),
      catchError(this.handleError)
    );
  }

  store(question: any): Observable<boolean> {
    return this.http.post(`${this._baseURL}store`, { data: question }).pipe(
      map(res => {
        if (res["data"]) return true;
        else return false;
      }),
      catchError(this.handleError)
    );
  }

  update(question: any): Observable<boolean> {
    return this.http.put(`${this._baseURL}update`, { data: question }).pipe(
      map(res => {
        if (res["data"]) return true;
        else return false;
      }),
      catchError(this.handleError)
    );
  }

  delete(id: string): Observable<boolean> {
    const params = new HttpParams().set("id", id);
    return this.http.delete(`${this._baseURL}remove`, { params: params }).pipe(
      map(res => {
        return true;
      }),
      catchError(this.handleError)
    );
  }

  private handleError(error: HttpErrorResponse) {
    console.log(error);

    // return an observable with a user friendly message
    return throwError("Error! something went wrong.");
  }
}
