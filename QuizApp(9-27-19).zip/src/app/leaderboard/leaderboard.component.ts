import { Component, OnInit } from '@angular/core';
import { playerService } from '../admin/leaderboard/players/player.service';

@Component({
  selector: 'app-leaderboard',
  templateUrl: './leaderboard.component.html',
  styleUrls: ['./leaderboard.component.css']
})
export class LeaderboardComponent implements OnInit {
  all_players : any;
  constructor(private pService: playerService) { }

  ngOnInit() {
    this.getPlayers(); 
  }

  getPlayers() {
    this.pService.getAllPlayersByRank().subscribe((res) => {
      this.all_players = res;
    })
  }
}
