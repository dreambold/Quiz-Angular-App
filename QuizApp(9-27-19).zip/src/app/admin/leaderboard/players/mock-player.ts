import { Iplayer } from '../players/player.model';


export const Players: Iplayer[]=[
 
]