import { Component, OnInit, Input } from "@angular/core";
import { Iplayer } from "./player.model";
import { Router } from "@angular/router";
import { playerService } from "./player.service";
import { authService } from "src/app/auth.service";

@Component({
  selector: "app-players",
  templateUrl: "./players.component.html",
  styleUrls: ["./players.component.css"]
})
export class PlayersComponent implements OnInit {
  players: Iplayer[];
  all_players: any;
  player_result: [];
  constructor(
    private router: Router,
    private pService: playerService,
    private _authService: authService
  ) {
    this.players = [];
  }

  ngOnInit() {
    this.getPlayers();
  }

  getPlayers() {
    this.pService.getAllPlayersByRank().subscribe(res => {
      this.all_players = res;
    });
  }

  get_results(item) {
    this.pService.get_all_result_by_user(item.id).subscribe(res => {
      this.player_result = res.data;
      console.log(res);
    });
  }

  onClick(event: Event): void {
    this.router.navigate(["/Register"]);
  }
  LBoard(event: Event): void {
    this._authService.login();
    event.preventDefault(); // Prevents browser following the link
    this.router.navigate(["/player"]);
  }

  users(event: Event): void {
    this._authService.login();
    event.preventDefault(); // Prevents browser following the link
    this.router.navigate(["/users"]);
  }

  logout(event: Event): void {
    this._authService.logout();
    //event.preventDefault(); // Prevents browser following the link
    localStorage.removeItem("loggedInUser");
    this.router.navigate(["/quiz"]);
  }
  setup(event: Event): void {
    this._authService.login();
    event.preventDefault(); // Prevents browser following the link
    this.router.navigate(["/dashboard"]);
  }
  onClickee(event: Event): void {
    this._authService.login();
    event.preventDefault(); // Prevents browser following the link
    this.router.navigate(["/Register"]);
  }
}
