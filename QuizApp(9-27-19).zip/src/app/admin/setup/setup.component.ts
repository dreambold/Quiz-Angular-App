import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';

import { QuestionService } from '../../services/question.service';
import { Router } from '@angular/router';
import { AdminComponent } from '../admin.component';

@Component({
  selector: 'admin-setup',
  templateUrl: './setup.component.html',
  styleUrls: ['./setup.component.css', '../admin.component.css']
})
export class SetupComponent implements OnInit {
  @Input() question: any;
  @Input() questionNo: number;
  qForm: FormGroup;
  options: FormArray;
  errors: string[];
  formSubmitted: boolean;
  questionObj: any;
  icons: string[];
  editQuestion: boolean;
  constructor(private formBuilder: FormBuilder,
    private questionService: QuestionService, 
    private router: Router) { 
    this.errors = [];
    this.icons = ['good','doubt','read','teach', 'email-transfert', 'copy', 'create', 'byod', 'run', 'laugh', 'grumble', 'shame', 'click', 'accept', 'stop', 'none',
      'call', 'usb', 'email', 'dropbox', 'handshake', 'boss', 'payback', 'worry', 'secure', 'happy', 'lock', 'angel', 'coffee', 'shutdown', 'search', 'tea', 'relax', 
      'warn', 'desk', 'cocktail', 'idea', 'keep', 'move', 'lookusb', 'update', 'bollard', 'buy', 'trash', 'unlock', 'object', 'ask', 'headset', 'reward', 'educ', 'police',
      'recommend', 'wifi', 'give', 'bad', 'star', 'antivirus', 'recycling', 'gift', 'kids', 'drill', 'boxing'];
    this.formSubmitted = false;
    this.editQuestion = false;
    this.qForm = this.formBuilder.group({
      heading: ['', [Validators.required]],
      subHeading: ['', [Validators.required]],
      id: [''],
      options: this.formBuilder.array([ this.createItem() ])
    });
  }

  ngOnInit() {
    if(this.question){
      for (let index = 0; index < this.question.options.length-1; index++) {
        this.addItem();
      }
      this.qForm.setValue(this.question);
      this.editQuestion = true;
    }
  }

  get f() { return this.qForm.controls; }

  get formData() { return <FormArray>this.qForm.get('options'); }

  createItem(): FormGroup {
    return this.formBuilder.group({
      oText: ['', [Validators.required]],
      gradeId: ['', [Validators.required]],
      rText: ['', [Validators.required]],
      rmText: [''],
      icon: ['', [Validators.required]],
      id: ['']
    });
  }

  addItem(): void {
    this.options = this.qForm.get('options') as FormArray;
    this.options.push(this.createItem());
  }

  removeItem(index): void {
    this.options = this.qForm.get('options') as FormArray;
    this.options.removeAt(index);
  }

  save(){
    this.errors=[];
    let options = this.qForm.value.options;
    this.formSubmitted = true;
    if(this.qForm.invalid){
      return;
    }

    if(options.length < 2){
        this.errors.push('add atleast 2 options in a question');
        window.scroll(0,0);
        return;
    }
    
    this.questionObj = this.qForm.value;
    this.questionObj.options.forEach(option => {
      option.gradeId = parseInt(option.gradeId);
    });
    if(!this.editQuestion){
      this.questionService.store(this.questionObj).subscribe(
        (res: boolean) => {
          if(res){
            // Redirect the user
            window.location.reload();
          }
          else{
            this.errors.push('Data not saved! Try Again');
            window.scroll(0,0);
          }
        },
        (err) => {
          this.errors.push(err);
        }); 
    }
    else{
      this.questionService.update(this.questionObj).subscribe(
        (res: boolean) => {
          if(res){
            // Redirect the user
            window.location.reload();
          }
          else{
            this.errors.push('Data not saved! Try Again');
            window.scroll(0,0);
          }
        },
        (err) => {
          this.errors.push(err);
        }); 
    }
    
  }

  selectIcon(iconIndex, i){
    this.options = this.qForm.get('options') as FormArray;
    this.options.controls[i].patchValue({icon: this.icons[iconIndex]});
  }

  goBack(){
    window.location.reload();

    
  }

}
