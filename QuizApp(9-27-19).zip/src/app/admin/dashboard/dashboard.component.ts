import { Component, OnInit } from '@angular/core';
import { QuestionService } from '../../services/question.service';
import { Router } from '@angular/router';
import { authService } from 'src/app/auth.service';

@Component({
  selector: 'admin-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css', '../admin.component.css']
})
export class DashboardComponent implements OnInit {
  question: any;
  questions: any[];
  errors: string[];
  showListPage: boolean;
  questionNo: number;
  constructor(private questionService: QuestionService ,private _authService: authService, private router: Router, private _authservice: authService) { 
    this.showListPage = true;
  }

  ngOnInit() {
    this.questions = [];
    this.errors = [];
    this.question = null;
    this.questionNo = 0;
    this.getQuestions();
  }

  onClickee(event: Event): void {
this._authservice.login();
    this.router.navigate(['/Register']);
  }
  LBoard(event: Event): void {
    this._authService.login();
    this.router.navigate(['/player']);
  }
  users(event: Event): void {
    this._authService.login();
    this.router.navigate(['/users']);
  }
 
  getQuestions(): void {
    this.questionService.getAll().subscribe(
      (res: any[]) => {
        this.questions = res;
      },
      (err) => {
        this.errors.push(err);
      }
    );
  }

  editQuestion(question){
    this.question = question;
    this.showListPage = false;
  }

  addQuestion(){
    this.questionNo = this.questions.length+1;
    this.showListPage = false;
  }

  deleteQuestion(id, index){
    this.questionService.delete(id).subscribe(
      (res: boolean) => {
        if(res){
          // Redirect the user
          this.questions.splice(index, 1);
        }
        else{
          this.errors.push('Data not deleted! Try Again');
          window.scroll(0,0);
        }
      },
      (err) => {
        this.errors.push(err);
      }); 
  }

  // logout(){
  //   localStorage.clear();
  //   window.location.reload();
  // }
  logout(event: Event): void {
    localStorage.removeItem('loggedInUser');
    this.router.navigate(['/quiz']);
  }

}
