import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { UserService } from "../services/user.service";
import { authService } from "../auth.service";
import { Router } from "@angular/router";

@Component({
  selector: "app-admin",
  templateUrl: "./admin.component.html",
  styleUrls: ["./admin.component.css"]
})
export class AdminComponent implements OnInit {
  loginForm: FormGroup;
  errors: string[];
  showDashboard: boolean;
  constructor(
    private formBuilder: FormBuilder,
    private userService: UserService,
    private _authService: authService,
    private router: Router
  ) {
    this.errors = [];
    this.showDashboard = false;
    this.loginForm = this.formBuilder.group({
      username: ["", [Validators.required]],
      password: ["", [Validators.required]]
    });
  }

  ngOnInit() {
    if (localStorage.getItem("loggedInUser") == "admin") {
      this.showDashboard = true;
    }
  }

  get f() {
    return this.loginForm.controls;
  }

  login() {
    if (this.loginForm.invalid) return;

    this.errors = [];
    const username = this.loginForm.value.username.toLowerCase().trim();
    const password = this.loginForm.value.password;

    this.userService.login(username, password).subscribe(
      (res: boolean) => {
        if (res) {
          localStorage.setItem("loggedInUser", "admin");
          this._authService.login();
          this.router.navigate(["/dashboard"]);
          //this.showDashboard = true;
        } else {
          this.errors.push("Invalid Username or Password");
        }
      },
      err => {
        this.errors.push(err);
      }
    );
  }
}
