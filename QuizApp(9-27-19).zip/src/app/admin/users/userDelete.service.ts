import { Injectable } from "@angular/core";
import {
  HttpClient,
  HttpErrorResponse,
  HttpParams
} from "@angular/common/http";
import { map, tap } from "rxjs/operators";
import { AppConstants } from "../../constants";
import { Observable, throwError } from "rxjs";
import { catchError } from "rxjs/operators";

@Injectable()
export class userDeleteService {
  _baseURL: string;
  constructor(private http: HttpClient) {
    this._baseURL = AppConstants.baseURL;
  }

  private handleError(error: HttpErrorResponse) {
    console.log(error);

    // return an observable with a user friendly message
    return throwError("Error! something went wrong.");
  }

  deleteUsers(articleId: any): Observable<any> {
    let params = new HttpParams().set("id", articleId);
    let cpHeaders = new Headers({ "Content-Type": "application/json" });
    return this.http
      .delete<any>(`${this._baseURL}delete-user`, { params: params })
      .pipe(
        map(data => {
          return <any>data;
        }),
        catchError(this.handleError)
      );
  }
}
