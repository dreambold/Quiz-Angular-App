import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { authService } from 'src/app/auth.service';
import { NgForm } from '@angular/forms';
import { UserService } from '../../services/user.service';
import { UserCreateModel } from '../../models/user.model';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-user-register',
  templateUrl: './user-register.component.html',
  styleUrls: ['./user-register.component.css', '../admin.component.css']
})

export class UserRegisterComponent implements OnInit {
  
  user_data = {
    name: "",
    email: "",
    phone_no: ""
  }

  userCreateModel: UserCreateModel;
  constructor(private router: Router, private _authService: authService,
    private uService: UserService) { 
  }

  ngOnInit() {

  }
  logout(event: Event): void {
    this._authService.logout();
    //event.preventDefault(); // Prevents browser following the link
    localStorage.removeItem('loggedInUser');
    this.router.navigate(['/quiz']);
  }


  onClickee(event: Event): void {
    this._authService.login();
    this.router.navigate(['/Register']);
  }

  users(event: Event): void {
    this._authService.login();
    this.router.navigate(['/users']);
  }
  setup(event: Event): void {
    this._authService.login();
    event.preventDefault(); // Prevents browser following the link
    this.router.navigate(['/dashboard']);
  }

  LBoard(event: Event): void {
    this._authService.login();
    event.preventDefault(); // Prevents browser following the link
    this.router.navigate(['/player']);
  }

  createUser() {   
    this.uService.createUser(this.user_data).subscribe(
      (res: any) => {
        console.log(res);
        
      },
      (err) => {

      });
      //document.getElementById("reg-form").reset() as HTMLElement;   
    // Swal.fire('User Created');

     Swal.fire({
      title: 'User Created',
      confirmButtonColor: '#dfb053',
    });



  }
}
