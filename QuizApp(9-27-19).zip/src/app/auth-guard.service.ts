import { CanActivate } from "@angular/router/src/utils/preactivation";
import {
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  Router
} from "@angular/router";
import { Observable } from "rxjs/internal/observable";
import { promise } from "protractor";
import { Injectable } from "@angular/core";
import { authService } from "./auth.service";

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private authService: authService, private router: Router) {}
  path: ActivatedRouteSnapshot[];
  route: ActivatedRouteSnapshot;
  //     CanActivate (route: ActivatedRouteSnapshot, state: RouterStateSnapshot) : Observable<boolean> | Promise<boolean> | boolean {
  //  return this.authService.isAuthenticated()
  // .then(
  //     (authenticated:boolean)=>{
  //         if(authenticated){
  //             return true;
  //         }
  //         else{
  // this.router.navigate(['quiz']);
  // return false;
  //         }
  //     }
  // )
  //     }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Promise<boolean> | boolean {
    return new Promise(resolve =>
      this.authService
        .isAuthenticated()
        .then((authenticated: boolean) => {
          if (authenticated === false) {
            this.router.navigate(["/quiz"]);
          }
          resolve(authenticated);
        })
        .catch(() => {
          this.router.navigate(["/quiz"]);
          resolve(false);
          // ... or any other way you want to handle such error case
        })
    );
  }
}
