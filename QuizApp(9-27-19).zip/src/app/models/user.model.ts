export class UserCreateModel {
    phone_no: string;
    email: string;
    name: string; 
}