import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';


import { AppComponent } from './app.component';
import { QuizComponent } from './quiz/quiz.component';
import { MalihuScrollbarModule } from 'ngx-malihu-scrollbar';
import { AdminComponent } from './admin/admin.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SetupComponent } from './admin/setup/setup.component';
import { DashboardComponent } from './admin/dashboard/dashboard.component';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { authService } from './auth.service';
import { AuthGuard } from './auth-guard.service';
import { LogoutComponent } from './logout/logout.component';
import { UserRegisterComponent } from './admin/user-register/user-register.component';
import { LeaderboardComponent } from './admin/leaderboard/leaderboard.component';
import { LeaderboardComponent as lbc } from './leaderboard/leaderboard.component';
import { PlayersComponent as pc } from './leaderboard/players/players.component';
import { PlayersComponent } from './admin/leaderboard/players/players.component';
import { UserService } from './services/user.service';
import { UsersComponent } from './admin/users/users.component'; 
import { userDeleteService } from './admin/users/userDelete.service';

@NgModule({
  declarations: [
    AppComponent,
    QuizComponent,
    AdminComponent,
    SetupComponent,
    DashboardComponent,
    LeaderboardComponent,
    LogoutComponent,
    PlayersComponent,
    UserRegisterComponent,
    lbc,
    pc,
    UsersComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    MalihuScrollbarModule.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    AngularFontAwesomeModule
  ],
  providers: [authService, AuthGuard, UserService, userDeleteService],
  bootstrap: [AppComponent]
})
export class AppModule { }
