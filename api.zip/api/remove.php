<?php

require 'connect.php';


// Extract, validate and sanitize the username.
$id = ($_GET['id'] !== null)? mysqli_real_escape_string($con, (string)$_GET['id']) : '';

if(!$id)
{
  return http_response_code(400);
}

// Delete.
$sql = "Delete FROM `options` WHERE `qId` =${id}";

if(mysqli_query($con, $sql))
{
	$osql = "Delete FROM `questions` WHERE `id` =${id}";
	if(mysqli_query($con,$osql)){
		return http_response_code(204);
	}
	else
	{
	  return http_response_code(422);
	}
		
}
else
{
  return http_response_code(422);
}