<?php

require 'connect.php';

// Extract, validate and sanitize the username.
$username = ($_GET['username'] !== null)? mysqli_real_escape_string($con, (string)$_GET['username']) : '';
$password = ($_GET['password'] !== null)? mysqli_real_escape_string($con, (string)$_GET['password']) : '';

if(!$username || !$password)
{
  return http_response_code(400);
}

// Delete.
$sql = "SELECT * FROM `users` WHERE `username` ='{$username}' and `password` ='{$password}' limit 1";

if($result = mysqli_query($con, $sql))
{
	if(mysqli_num_rows($result) == 0){
		echo json_encode(['data'=>false]);
	}
	else{
		echo json_encode(['data'=>true]);
	}
}
else
{
  return http_response_code(422);
}