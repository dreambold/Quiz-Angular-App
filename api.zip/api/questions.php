<?php
/**
 * Returns the list of questions.
 */
require 'connect.php';
    
$questions = [];
$sql = "SELECT q.heading, q.subHeading, o.qId, o.oText, o.gradeId, o.rText, o.rmText, o.icon, o.id as oId FROM questions q inner join options o on q.id = o.qId order by qId,o.id;";

if($result = mysqli_query($con,$sql))
{
  $qIndex = -1;
  $oIndex = 0;
  $current_ques = null;
  while($row = mysqli_fetch_assoc($result))
  {
	if ($row["qId"] != $current_ques) {
		$current_ques = $row["qId"];
		$qIndex++;
		$oIndex = 0;
		$questions[$qIndex]['options'] = [];
	}
	
	if($oIndex == 0){
		$questions[$qIndex]['heading']    = $row['heading'];
		$questions[$qIndex]['subHeading'] = $row['subHeading'];
		$questions[$qIndex]['id'] = $row['qId'];
	}
	
	$questions[$qIndex]['options'][$oIndex]['oText'] = $row['oText'];
	$questions[$qIndex]['options'][$oIndex]['icon'] = $row['icon'];
	$questions[$qIndex]['options'][$oIndex]['gradeId'] = $row['gradeId'];
	$questions[$qIndex]['options'][$oIndex]['rText'] = $row['rText'];
	$questions[$qIndex]['options'][$oIndex]['rmText'] = $row['rmText'];
	$questions[$qIndex]['options'][$oIndex]['id'] = $row['oId'];
	$oIndex++;
  }
    
  echo json_encode(['data'=>$questions]);
}
else
{
  http_response_code(404);
}