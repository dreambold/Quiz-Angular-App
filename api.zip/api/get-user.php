<?php
/**
 * Returns the list of questions.
 */
require 'connect.php';

// Extract, validate and sanitize the username.
$username = ($_GET['username'] !== null)? mysqli_real_escape_string($con, (string)$_GET['username']) : '';
 
if(!$username)
{
  return http_response_code(400);
}
    
$user;
$sql = "SELECT * FROM users WHERE `username` ='{$username}' limit 1";

if($result = mysqli_query($con,$sql))
{
	if(mysqli_num_rows($result) == 0){
		echo json_encode(['data'=>false]);
	}else{
		while($row = mysqli_fetch_assoc($result))
		{ 
		    $sql2 = "SELECT * FROM results WHERE `userId` =".$row['id']." ORDER BY date DESC limit 1"; 
		    $result2 = mysqli_query($con,$sql2);
		    if(mysqli_num_rows($result2) != 0){
		    while($row2 = mysqli_fetch_assoc($result2)){
		        $date1 = date('Y-m-d h:i:s', strtotime($row2['date']));   
		        $date1 = strtotime($date1);
		        $date2= date('Y-m-d h:i:s', strtotime('+5 hours')); 
                $date2 = strtotime($date2); 
                // Formulate the Difference between two dates 
                 
$diff = abs($date1 - $date2);  
   
$years = floor($diff / (365*60*60*24));  
   
$months = floor(($diff - $years * 365*60*60*24) 
                               / (30*60*60*24));  
   
$days = floor(($diff - $years * 365*60*60*24 -  
             $months*30*60*60*24)/ (60*60*24)); 
  
$hours = floor(($diff - $years * 365*60*60*24  
       - $months*30*60*60*24 - $days*60*60*24) 
                                   / (60*60));  
   
$minutes = floor(($diff - $years * 365*60*60*24  
         - $months*30*60*60*24 - $days*60*60*24  
                          - $hours*60*60)/ 60);  
    
$seconds = floor(($diff - $years * 365*60*60*24  
         - $months*30*60*60*24 - $days*60*60*24 
                - $hours*60*60 - $minutes*60));
                if($minutes > 15){
                    $user['username'] = $row['username'];
			        $user['id'] = $row['id'];
			     //   $user['minuts'] = $minutes;
			        print_r(json_encode(['data'=>$user]));
                } else {
                    echo "You Just Played The Game ".$minutes." Minuts Ago, Wait for total 15 minuts to try again";
                }
		    } 
		    } else {
		        $user['username'] = $row['username'];
			        $user['id'] = $row['id'];
			        print_r(json_encode(['data'=>$user]));
		    }
		}
		
	}
    
}
else
{
  http_response_code(404);
}