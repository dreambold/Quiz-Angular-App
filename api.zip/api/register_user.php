
application/x-httpd-php register_user.php ( PHP script, ASCII text, with CRLF line terminators )
<?php
require 'connect.php';

// Get the posted data.
$postdata = file_get_contents("php://input");

if(isset($postdata) && !empty($postdata))
{
  // Extract the data.
  $request = json_decode($postdata); 
  // Sanitize.
  $username = str_replace(' ', '', $request->data->name);
  $username = strtolower($username)."".rand(0,1000);
  $name = $request->data->name;
  $email = $request->data->email;
  $phone_no = $request->data->phone_no;  
  $user;
  // Store.
  $sql = "INSERT INTO `users`(`id`,`username`, `password`, `name`, `phone_no`, `email`) VALUES (NULL,'{$username}', NULL, '{$name}', '{$phone_no}', '{$email}')";
 
  if(mysqli_query($con,$sql))
  {
	  $user['username'] = $username;
	  $user['name'] = $name;
	  $user['email'] = $email;
	  $user['phone_no'] = $phone_no; 
	  $user['id'] = mysqli_insert_id($con);
	  http_response_code(201);
	  echo json_encode(['data'=>$user]);
  }
  else
  {
    http_response_code(422);
	echo json_encode(['data'=>false]);
  }
}