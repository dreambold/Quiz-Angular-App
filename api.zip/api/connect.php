<?php

// db credentials
define('DB_HOST', 'localhost');
define('DB_USER', 'psltwlwt_shanawar');
define('DB_PASS', 'r3m3mb3r');
define('DB_NAME', 'psltwlwt_quizdb');

//define('DB_HOST', 'localhost');
//define('DB_USER', 'psltwlwt_admin');
//define('DB_PASS', 'admin1234');
//define('DB_NAME', 'psltwlwt_security_quiz');

// Connect with the database.
function connect()
{
  $connect = mysqli_connect(DB_HOST ,DB_USER ,DB_PASS ,DB_NAME);

  if (mysqli_connect_errno($connect)) {
    die("Failed to connect:" . mysqli_connect_error());
  }

  mysqli_set_charset($connect, "utf8");

  return $connect;
}

$con = connect();

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
	header('Access-Control-Allow-Origin: *');
	header('Access-Control-Allow-Methods: POST, GET, DELETE, PUT, PATCH, OPTIONS');
	header('Access-Control-Allow-Headers: token, Content-Type');
	die();
}
 
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
