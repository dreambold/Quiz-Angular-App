<?php
/**
 * Returns the list of questions.
 */
require 'connect.php';

// Extract, validate and sanitize the username.
$userId = ($_GET['userId'] !== null)? mysqli_real_escape_string($con, (string)$_GET['userId']) : '';

if(!$userId)
{
  return http_response_code(400);
}
    
$userResult;
$sql = "SELECT * FROM results WHERE `userId` ={$userId} and `status`= 'pending' limit 1";

if($result = mysqli_query($con,$sql))
{
	if(mysqli_num_rows($result) == 0){
		echo json_encode(['data'=>false]);
	}
	else{
		while($row = mysqli_fetch_assoc($result))
		{
			$userResult['obtainedMarks'] = $row['obtainedMarks'];
			$userResult['totalMarks'] = $row['totalMarks'];
			$userResult['userId'] = $row['userId'];
			$userResult['time'] = $row['time'];
			$userResult['id'] = $row['id'];
			$userResult['status'] = $row['status'];
			$userResult['questionNo'] = $row['questionNo'];
			$userResult['randomNumbers'] = $row['randomNumbers'];
		}
		echo json_encode(['data'=>$userResult]);
	}
    
}
else
{
  http_response_code(404);
}