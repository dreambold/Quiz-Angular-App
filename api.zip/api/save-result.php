<?php
require 'connect.php';

// Get the posted data.
$postdata = file_get_contents("php://input");

if(isset($postdata) && !empty($postdata))
{
  // Extract the data.
  $request = json_decode($postdata);
	

  // Validate.
  if(trim($request->data->time) === '')
  {
    return http_response_code(400);
  }
	
  // Sanitize.
  $resultId = $request->data->id;
  $obtainedMarks = $request->data->obtainedMarks;
  $totalMarks = $request->data->totalMarks;
  $userId = $request->data->userId;
  $time = $request->data->time;
  $status = $request->data->status;
  $questionNo = $request->data->questionNo;
  $randomNumbers = $request->data->randomNumbers;
  // Store.
  
  if($resultId == 0){
	  $sql = "INSERT INTO `results`(`obtainedMarks`,`totalMarks`,`userId`,`time`, `questionNo`, `randomNumbers`) VALUES ({$obtainedMarks},{$totalMarks},{$userId},'{$time}', {$questionNo}, '{$randomNumbers}')";
  }
  else{
	  $sql= "UPDATE `results` SET `obtainedMarks`='$obtainedMarks',`totalMarks`='$totalMarks', `time`='$time', `questionNo`='$questionNo', `randomNumbers`='$randomNumbers', `status`='$status' WHERE `id` = {$resultId}";
  }

  if(mysqli_query($con,$sql))
  {
	  if($resultId == 0){
		  $resultId = mysqli_insert_id($con);
	  }
	  http_response_code(201);
	  echo json_encode(['data'=>$resultId]);
  }
  else
  {
    http_response_code(422);
	echo json_encode(['data'=>false]);
  }
}