<?php
/**
 * Returns the list of questions.
 */
require 'connect.php';

// Extract, validate and sanitize the username.
// $username = ($_GET['username'] !== null)? mysqli_real_escape_string($con, (string)$_GET['username']) : '';

// if(!$username)
// {
//   return http_response_code(400);
// }
    
$user;
$sql = "SELECT * FROM users";

if($result = mysqli_query($con,$sql))
{
	if(mysqli_num_rows($result) == 0){
		echo json_encode(['data'=>false]);
	}
	else{
	    $data = array();
		while($row = mysqli_fetch_assoc($result))
		{
			$user['username'] = $row['username'];
			$user['id'] = $row['id'];
			$user['name'] = $row['name'];
			$user['phone_no'] = $row['phone_no'];
			$user['email'] = $row['email'];
			$user['nickname'] = $row['nickname'];
			array_push($data, $user);
		}
		print_r(json_encode(['data'=>$data]));
// print_r($data);
	}
    
}
else
{
  http_response_code(404);
}