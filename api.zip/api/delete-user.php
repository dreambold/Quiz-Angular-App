<?php

require 'connect.php';


// Extract, validate and sanitize the username.
$id = ($_GET['id'] !== null)? mysqli_real_escape_string($con, (string)$_GET['id']) : '';

if(!$id)
{
  return http_response_code(400);
}

// Delete.
$sql = "Delete FROM `users` WHERE `id` =${id}";

if(mysqli_query($con, $sql))
{ 
    echo "user deleted"; 	
}else{
  return http_response_code(422);
}