<?php
/**
 * Returns the list of questions.
 */
require 'connect.php';

// Extract, validate and sanitize the username.
$userId = ($_GET['userId'] !== null)? mysqli_real_escape_string($con, (string)$_GET['userId']) : '';

if(!$userId)
{
  return http_response_code(400);
}
    
$userResult;
$sql = "SELECT * FROM results WHERE `userId` = {$userId} and `status`= 'completed' order by obtainedMarks desc";

if($result = mysqli_query($con,$sql))
{
	$rIndex = 0;
	if(mysqli_num_rows($result) == 0){
		echo json_encode(['data'=>false]);
	}
	else{
	    $data = array();
		while($row = mysqli_fetch_assoc($result))
		{
		    $userResult['id'] = $row['id'];
			$userResult['obtainedMarks'] = $row['obtainedMarks'];
			$userResult['totalMarks'] = $row['totalMarks'];
			$userResult['time'] = $row['time'];
			$userResult['date'] = $row['date'];
			$rIndex++;
			array_push($data, $userResult);
		}
		
		print_r(json_encode(['data'=>$data]));
	}
    
}
else
{
  http_response_code(404);
}