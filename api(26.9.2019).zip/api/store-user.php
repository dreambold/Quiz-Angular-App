<?php
require 'connect.php';

// Get the posted data.
$postdata = file_get_contents("php://input");

if(isset($postdata) && !empty($postdata))
{
  // Extract the data.
  $request = json_decode($postdata);
	

  // Validate.
  if(trim($request->data->username) === '')
  {
    return http_response_code(400);
  }
	
  // Sanitize.
  $username = mysqli_real_escape_string($con, trim($request->data->username));
  
  $user;
  // Store.
  $sql = "INSERT INTO users(`username`) VALUES ('{$username}')";

  if(mysqli_query($con,$sql))
  {
	  $user['username'] = $username;
	  $user['id'] = mysqli_insert_id($con);
	  http_response_code(201);
	  echo json_encode(['data'=>$user]);
  }
  else
  {
    http_response_code(422);
	echo json_encode(['data'=>false]);
  }
}