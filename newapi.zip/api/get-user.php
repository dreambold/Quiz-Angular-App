<?php

/**
 * Returns the list of questions.
 */

require 'connect.php';

// Extract, validate and sanitize the username.
$username = ($_GET['username'] !== null) ? mysqli_real_escape_string($con, (string) $_GET['username']) : '';

if (!$username) {
    return http_response_code(400);
}

$user;
$sql = "SELECT * FROM users WHERE `username` ='{$username}' limit 1";

if ($result = mysqli_query($con, $sql)) {
    if (mysqli_num_rows($result) == 0) {
        echo json_encode(['data' => false]);
    } else {
        while ($row = mysqli_fetch_assoc($result)) {
            $sql2 = "SELECT * FROM `results` WHERE `userId` =" . $row['id'] . " ORDER BY date DESC limit 1";
            $result2 = mysqli_query($con, $sql2);
            if (mysqli_num_rows($result2) != 0) {
                while ($row2 = mysqli_fetch_assoc($result2)) {
                    $date1 = date('Y-m-d H:i:s', strtotime($row2['date']));
                    $date1 = strtotime($date1);
                    $date2 = date('Y-m-d H:i:s', strtotime('now'));
                    $date2 = strtotime($date2);
                    // Formulate the Difference between two dates

                    $diff = $date2 - $date1;

                    // $YY = date('Y', $diff);
                    // $mm = date('m', $diff);
                    // $dd = date('d', $diff);
                    // $HH = date('H', $diff);
                    $ii = date('i', $diff);
                    $ss = date('s', $diff);
                    // default $minutes = 15
                    if ($ss > 5) {
                        $user['username'] = $row['username'];
                        $user['id'] = $row['id'];
                        //   $user['minuts'] = $minutes;
                        print_r(json_encode(['data' => $user, 'time' => $ii . ' : ' . $ss]));
                    } else {
                        echo "You Just Played The Game " . $ii . " Minuts " . $ss . " seconds Ago, Wait for total 15 minuts to try again";
                    }
                }
            } else {
                $user['username'] = $row['username'];
                $user['id'] = $row['id'];
                print_r(json_encode(['data' => $user, 'loc' => 'error']));
            }
        }
    }
} else {
    http_response_code(404);
}