import { Component, OnInit } from '@angular/core';
import { playerService } from './admin/leaderboard/players/player.service';
import { Iplayer } from './admin/leaderboard/players/player.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers:[playerService]
})
export class AppComponent implements OnInit {
  //courses: Course[];
  error = '';
  success = '';
  introDiv: HTMLElement;
  startDiv: HTMLElement;
  scrollSliderDiv: HTMLElement;
  guageDiv: HTMLElement;
  gaugeScore: HTMLElement;
  gaugeCursor: HTMLElement;
  panelMain: HTMLElement;
  introFadeOut: boolean;
  startFadeIn: boolean;
  gameFadeIn: boolean;
  showResultQuestion: boolean;
  optionSelected: boolean;
  showResultPanel: boolean;
  listItem: number;
  questions: any[];
  currentQuestionIndex: number;
  currentScore: number;
  questionGrade: string;
  questionIcon: string;
  questionOptions: any[];


  players: Iplayer[];
  selectedPlayer: Iplayer;
  constructor(private PlayerService: playerService) { }

  ngOnInit(): void {
  }

 
  onSelect(player: Iplayer): void {
    this.selectedPlayer = player;
  }
}
