import { Component, OnInit } from '@angular/core';
import { MalihuScrollbarService } from 'ngx-malihu-scrollbar';
import { QuestionService } from '../services/question.service';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';
import { authService } from '../auth.service';
import Swal from 'sweetalert2';
declare var $: any;

@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {
  error = '';
  success = '';
  introDiv: HTMLElement;
  startDiv: HTMLElement;
  scrollSliderDiv: HTMLElement;
  guageDiv: HTMLElement;
  gaugeScore: HTMLElement;
  gaugeCursor: HTMLElement;
  panelMain: HTMLElement;
  introFadeOut: boolean;
  startFadeIn: boolean;
  gameFadeIn: boolean;
  showResultQuestion: boolean;
  optionSelected: boolean;
  showResultPanel: boolean;
  showGameStartPanel: boolean;
  showUsernameError: boolean;
  securityBreached: boolean;
  showPreviousResultPanel: boolean;
  listItem: number;
  questions: any[];
  currentQuestionIndex: number;
  currentScorePercentage: number;
  questionGrade: string;
  questionGradebkp: string;
  questionIcon: string;
  questionOptions: any[];
  resultText: string;
  readMoreText: string;
  user: any;
  hours: number;
  minutes: number;
  secs: number;
  totalScore: number;
  obtainedScore: number;
  result: any;
  prevResults: any[];
  questionsDb: any[];
  randomNumbers: number[];
  interval;

  constructor(private mScrollbarService: MalihuScrollbarService,
    private questionService: QuestionService,
    private userService: UserService,
    private _authService: authService,
    private router: Router) {
    this.questions = [];
    this.questionOptions = [];
    this.prevResults = [];
    this.questionsDb = [];
    this.randomNumbers = [];
    this.user = {
      id: 0,
      username: ''
    };
    this.showUsernameError = false;
    this.securityBreached = false;
    this.showPreviousResultPanel = false;
    this.hours = 0;
    this.minutes = 0;
    this.secs = 0;

  }

  ngAfterViewInit() {
    this.mScrollbarService.initScrollbar('#scroll-slider', { axis: 'yx', theme: '3d', scrollButtons: { enable: true } });
  }

  ngOnInit() {
    this.getQuestions();
  }

  getQuestions(): void {
    this.questionService.getAll().subscribe(
      (res: any[]) => {
        this.questionsDb = res;
        this.assignRandomQuestions(null);
        this.introFadeOut = false;
        this.startFadeIn = false;
        this.gameFadeIn = false;
        this.showResultQuestion = false;
        this.optionSelected = false;
        this.showResultPanel = false;
        this.showGameStartPanel = false;
        this.listItem = 0;
        this.currentQuestionIndex = 0;
        this.currentScorePercentage = 50;
        this.totalScore = this.questions.length;
        this.obtainedScore = 0;
      },
      (err) => {
        this.error = err;
      }
    );
  }

  assignRandomQuestions(randomNums) {
    if (this.questionsDb.length < 10)
      return;
    this.questions = [];
    if (!randomNums) {
      this.randomNumbers = [];
      while (this.randomNumbers.length < 10) {
        var r = Math.floor(Math.random() * this.questionsDb.length);
        if (this.randomNumbers.indexOf(r) === -1) this.randomNumbers.push(r);
      }
    }
    else {
      this.randomNumbers = randomNums;
    }

    this.randomNumbers.forEach(index => {
      this.questions.push(this.questionsDb[index]);
    });
  }

  fadeTextAnimation() {
    this.introFadeOut = true;
    setTimeout(() => {
      this.startFadeIn = true;
      this.showListItem();
    }, 700);
  }

  showListItem() {
    this.introDiv = document.getElementById('intro') as HTMLElement;
    this.introDiv.style.display = 'none';
    this.listItem = this.listItem + 1;
    setTimeout(() => {
      if (this.listItem < 5) {
        this.showListItem();
      }
    }, 1300);
  }

  showMainContainer() {
    this.scrollSliderDiv = document.getElementById('scroll-slider') as HTMLElement;
    this.guageDiv = document.getElementById('bargauge') as HTMLElement;
    this.gaugeCursor = document.getElementById('gaugeCursor') as HTMLElement;
    this.gaugeScore = document.getElementById('gscore') as HTMLElement;
    this.panelMain = document.getElementById('panel-m') as HTMLElement;
    this.scrollSliderDiv.style.height = (window.innerHeight - 285) + 'px';
    this.guageDiv.style.height = (window.innerHeight - 285) + 'px';
    this.startFadeIn = false;
    setTimeout(() => {
      this.startDiv = document.getElementById('start') as HTMLElement;
      this.startDiv.style.display = 'none';
      this.gameFadeIn = true;
      this.showGameStartPanel = true;
    }, 700);
  }
  
  onClick(event: Event): void {
  localStorage.clear();
    this.router.navigate(['/logout']);
  }
  onClicke(event: Event): void {
    this.router.navigate(['/admin']);
  }

  exit(event: Event): void {
    localStorage.clear();
    this.router.navigate(['/newquiz']);
  }

  startGame() {
    if (this.user.username) {
      this.userService.getUser(this.user.username).subscribe(
        (res: any) => {
          if (res) {
            this.user = res;
            this.getResult();
          }
          else {
            // alert('Contact to Admin')
            //Swal.fire('Please Contact to admin for registeration')
            Swal.fire({
              title: 'Please Contact to admin for registeration',
              confirmButtonColor: '#dfb053',
            });
        
          }
        },
        (err) => {
          // alert('game not available')
          //Swal.fire('Please Wait for 15 minutes....')
          Swal.fire({
            title: 'Please Wait for 15 minutes....',
            confirmButtonColor: '#dfb053',
          });
        });
    }
    else {
      this.showUsernameError = true;
    }
  }

  storeUser() {
    this.userService.store({ username: this.user.username }).subscribe(
      (res: any) => {
        if (res) {
          this.user = res;
          this.showGameStartPanel = false;
          this.showUsernameError = false;
          this.insertQuestionOptions();
          this.startTimer();
        }
        else {
          alert('cannot start game.')
        }
      },
      (err) => {
        alert('cannot start game.')
      });
  }

  getResult() {
    this.userService.getResult(this.user.id).subscribe(
      (res: any) => {
        if (res) {
          this.result = res;
          this.obtainedScore = this.result.obtainedMarks;
          this.totalScore = this.result.totalMarks;
          let scorePointer = Math.floor(50 / this.questions.length);
          let wrongAnswers = (this.result.questionNo) - this.result.obtainedMarks;
          this.currentScorePercentage = this.currentScorePercentage - (wrongAnswers * scorePointer);
          this.currentScorePercentage = this.currentScorePercentage + (this.result.obtainedMarks * scorePointer);
          this.gaugeCursor.style.bottom = this.currentScorePercentage + '%';
          this.gaugeScore.style.height = this.currentScorePercentage + '%';
          let time = this.result.time.split(":");
          this.hours = time[0];
          this.minutes = time[1];
          this.secs = time[2];
          this.randomNumbers = this.result.randomNumbers.split(",");
          this.assignRandomQuestions(this.randomNumbers);
          this.currentQuestionIndex = this.result.questionNo;
        }
        this.showGameStartPanel = false;
        this.showUsernameError = false;
        this.insertQuestionOptions();
        this.startTimer();
      },
      (err) => {
        alert('cannot start game.')
      });
  }

  showQuestionResult(value) {
      var ans1 = $("div.response.selected div")[0];
      var id = ans1.attributes.id.value;
      if (id == 1) {
        ans1.style.background = "#558B6E";
      }
      else {
        ans1.style.background = "#C1292E";
      }
    setTimeout(() => {
      this.showResultQuestion = value;
      let scorePointer = Math.floor(50 / this.questions.length);
      window.scroll(0, 0);
      console.log("currentQuestionIndex 000 = ", this.currentQuestionIndex);

      if (!value && this.currentQuestionIndex != this.questions.length - 1) {
        this.optionSelected = false;
        this.currentQuestionIndex++;
        this.insertQuestionOptions();
        console.log("currentQuestionIndex 111 = ", this.currentQuestionIndex);
      } else this.currentQuestionIndex++;

      if (!value) {
        this.questionGrade = this.questionGradebkp;
        if (this.questionGrade == 'correct') {

          this.currentScorePercentage = this.currentScorePercentage + scorePointer;
          this.obtainedScore++;
        }
        else {
          this.currentScorePercentage = this.currentScorePercentage - scorePointer;
        }
        this.gaugeCursor.style.bottom = this.currentScorePercentage + '%';
        this.gaugeScore.style.height = this.currentScorePercentage + '%';
        this.readMoreText = '';
        this.saveResult();
      }
    }, 1000);
  }

  saveResult() {
    let result = {
      obtainedMarks: this.obtainedScore,
      totalMarks: this.totalScore,
      userId: this.user.id,
      time: this.hours + ":" + this.minutes + ":" + this.secs,
      status: 'pending',
      id: 0,
      questionNo: this.currentQuestionIndex,
      randomNumbers: this.randomNumbers.toString()
    }
    if (this.result) {
      result.id = this.result.id;
    }

    if (this.currentQuestionIndex - 1 == this.questions.length -1) {
      result.status = "completed";
      this.userService.saveResult(result).subscribe(
      (res: any) => {
        this.result = result;
        this.result.id = res;
      },
      (err) => {
      });
      // result.questionNo--;
      setTimeout(() => {
        localStorage.clear();
        this.router.navigate(['/newquiz']);
      }, 10000);
      this.viewResult();  
    } else {
      this.userService.saveResult(result).subscribe(
      (res: any) => {
        this.result = result;
        this.result.id = res;
      },
      (err) => {
      });
    }
    
  }

  selectOption(index) {
    this.questions[this.currentQuestionIndex].options.forEach(option => {
      option.selected = false;
    });
    this.questions[this.currentQuestionIndex].options[index].selected = true;
    this.questionGrade = this.questions[this.currentQuestionIndex].options[index].gradeId == 1 ? 'correct' : 'wrong';
    this.questionGradebkp = this.questionGrade;
    this.optionSelected = true;
    this.resultText = this.questions[this.currentQuestionIndex].options[index].rText;
    this.readMoreText = this.questions[this.currentQuestionIndex].options[index].rmText;

    if (this.questionGrade == 'wrong') {
      this.questionIcon = 'thumbKO';
    }
    else if (this.questionGrade == 'correct') {
      this.questionIcon = 'thumbOK';
    }
  }

  insertQuestionOptions() {
    this.questionOptions = [];
    let count = 1;
    this.questions[this.currentQuestionIndex].options.forEach(element => {
      setTimeout(() => {
        this.questionOptions.push(element);
        // console.log(this.questionOptions);
      }, 300 * count);
      count++;
    });
  }

  reloadPage() {
    this.pauseTimer();
    this.questionOptions = [];
    this.prevResults = [];
    this.showUsernameError = false;
    this.securityBreached = false;
    this.showPreviousResultPanel = false;
    this.hours = 0;
    this.minutes = 0;
    this.secs = 0;
    this.introFadeOut = false;
    this.startFadeIn = false;
    this.gameFadeIn = false;
    this.showResultQuestion = false;
    this.optionSelected = false;
    this.showResultPanel = false;
    this.showGameStartPanel = false;
    this.listItem = 0;
    this.currentQuestionIndex = 0;
    this.currentScorePercentage = 50;
    this.totalScore = this.questions.length;
    this.obtainedScore = 0;
    this.result = null;
    this.gameFadeIn = true;
    this.gaugeCursor.style.bottom = this.currentScorePercentage + '%';
    this.gaugeScore.style.height = this.currentScorePercentage + '%';
    this.assignRandomQuestions(null);
    this.questions.forEach(question => {
      question.options.forEach(option => {
        option.selected = false;
      });
    });
    this.insertQuestionOptions();
    this.startTimer();
  }

  startTimer() {
    this.interval = setInterval(() => {
      this.secs++;
      if (this.secs == 60) {
        this.minutes++;
        this.secs = 0;
      }
      if (this.minutes == 60) {
        this.hours++;
        this.minutes = 0;
      }
    }, 1000)
  }

  pauseTimer() {
    clearInterval(this.interval);
  }

  viewResult() {
    this.pauseTimer();
    this.showQuestionResult(false);
    let percentage = this.obtainedScore / this.totalScore * 100;
    console.log("percentage = ", percentage);
    if (percentage < 30) {
      this.securityBreached = true;
    }
    else {
      this.showResultPanel = true;
    }
  }

  fetchPreviousResults() {
    this.userService.getAllResults(this.user.id).subscribe(
      (res: any) => {
        if (res) {
          this.prevResults = [];
          let results = res;
          results.forEach(element => {
            let time = element.time.split(":");
            element.hours = time[0];
            element.minutes = time[1];
            element.secs = time[2];

            element.percentage = element.obtainedMarks / element.totalMarks * 100;

            let date = element.date.split(" ");
            element.date = date[0];
          });

          //group array by percentage
          let groupedArray = results.reduce(function (r, a) {
            r[a.percentage] = r[a.percentage] || [];
            r[a.percentage].push(a);
            return r;
          }, Object.create(null));

          let date = new Date('1970/01/01');
          const keys = Object.keys(groupedArray);
          let numKeys = [];
          keys.forEach(key => {
            numKeys.push(parseInt(key));
          });
          numKeys = numKeys.sort(this.sortNumber);
          for (const key of numKeys) {
            groupedArray[key].sort((obj1, obj2) => {
              obj1.sortTime = date.setHours(obj1.hours, obj1.minutes, obj1.secs);
              obj2.sortTime = date.setHours(obj2.hours, obj2.minutes, obj2.secs);
              if (obj1.sortTime > obj2.sortTime) {
                return -1;
              }
              if (obj1.sortTime <= obj2.sortTime) {
                return 1;
              }
              return 0;
            });
            groupedArray[key].forEach(element => {
              this.prevResults.unshift(element);
            });

          }

          console.log(groupedArray);
          this.showResultPanel = false;
          this.securityBreached = false;
          this.showPreviousResultPanel = true;
        }
      },
      (err) => {
        alert('cannot fetch results.')
      });
  }

  sortNumber(a, b) {
    return a - b;
  }

}
