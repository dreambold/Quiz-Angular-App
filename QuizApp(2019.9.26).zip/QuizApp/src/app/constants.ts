export class AppConstants {
  public static get baseURL(): string {
    return "http://localhost/api/";
  }
  // http://api.pslt20.stream/api/  --for deployment
  // http://localhost/api/ -- for localhost
  // "http://www.test.com/api/"; // On Local Server
}
