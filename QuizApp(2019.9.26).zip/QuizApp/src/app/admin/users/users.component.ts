import { Component, OnInit } from "@angular/core";
import { playerService } from "../leaderboard/players/player.service";
import { authService } from "src/app/auth.service";
import { Router } from "@angular/router";
import { userDeleteService } from "./userDelete.service";
import Swal from "sweetalert2";

@Component({
  selector: "app-users",
  templateUrl: "./users.component.html",
  styleUrls: ["./users.component.css", "../admin.component.css"]
})
export class UsersComponent implements OnInit {
  all_players: any;
  isLoadingResults = true;
  constructor(
    private router: Router,
    private pService: playerService,
    private _deleteuser: userDeleteService,
    private _authService: authService
  ) {}

  ngOnInit() {
    this.getPlayers();
  }

  getPlayers() {
    this.pService.getAllPlayers().subscribe(res => {
      this.all_players = res;
    });
  }

  onClick(event: Event): void {
    event.preventDefault(); // Prevents browser following the link
    this.router.navigate(["/Register"]);
  }
  LBoard(event: Event): void {
    this._authService.login();
    event.preventDefault(); // Prevents browser following the link
    this.router.navigate(["/player"]);
  }

  setups(event: Event): void {
    this._authService.login();
    event.preventDefault(); // Prevents browser following the link
    this.router.navigate(["/dashboard"]);
  }

  logout(event: Event): void {
    this._authService.logout();
    //event.preventDefault(); // Prevents browser following the link
    localStorage.removeItem("loggedInUser");
    this.router.navigate(["/quiz"]);
  }
  setup(event: Event): void {
    this._authService.login();
    event.preventDefault(); // Prevents browser following the link
    this.router.navigate(["/dashboard"]);
  }
  onClickee(event: Event): void {
    this._authService.login();
    event.preventDefault(); // Prevents browser following the link
    this.router.navigate(["/Register"]);
  }

  // deleteUser(any): void {
  //   this._deleteuser.deleteUsers(any)
  //     .subscribe(data => {
  //       this.employees = this.employees.filter(u => u !== employee);
  //     })
  // }
  deleteUser(id: number) {
    this._deleteuser.deleteUsers(id).subscribe(
      res => {
        Swal.fire("User Deleted");
      },
      err => {
        console.log(err);
      }
    );
    this.router.navigate(["/user"]);
    this.getPlayers();
  }
}
