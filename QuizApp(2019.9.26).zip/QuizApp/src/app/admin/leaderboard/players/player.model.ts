
export interface Iplayer {
    obtainedMarks: number,
    totalMarks: number,

}