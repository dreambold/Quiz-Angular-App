import { Injectable } from "@angular/core";
import { promise } from 'protractor';
import { Iplayer } from './player.model';
import { Observable } from 'rxjs/internal/Observable';
import { HttpParams, HttpClient, HttpErrorResponse } from '@angular/common/http';
import { User } from 'src/app/services/user';
import { map, catchError } from 'rxjs/operators';
import { throwError } from 'rxjs/internal/observable/throwError';
import { AppConstants } from '../../../constants';

@Injectable()
export class playerService {

    user: User;
    results: any[];
    _baseURL: string;
    constructor(private http: HttpClient) {
        this._baseURL = AppConstants.baseURL;
    }

    getPlayersResult() {
        return this.http.get<any>(`${this._baseURL}get-user-results`).pipe(
            map((res) => {
                return res;
            })
        );
    }

    get_all_result_by_user(userId: number): Observable<any> {
        let params = new HttpParams().set('userId', userId.toString());
        return this.http.get(`${this._baseURL}get-leaderboard-user-results`, { params: params }).pipe(
          map((res) => {
              return res ;
          }),
          catchError(this.handleError));
      }
    getAllResults(): Observable<any[]> {
        return this.http.get(`${this._baseURL}get-user-results`).pipe(
            map((res) => {
                this.results = res['data'];
                return this.results;
            }),
            catchError(this.handleError));
    }
    private handleError(error: HttpErrorResponse) {
        console.log(error);

        // return an observable with a user friendly message
        return throwError('Error! something went wrong.');
    }

    getAllPlayers(): Observable<any> {
        return this.http.get<any>(`${this._baseURL}get_all_users`).pipe(
            map((res) => {
                if (res['data'])
                    return res['data'];
                else
                    return null;
            }),
            catchError(this.handleError));
    }

    getAllPlayersByRank(): Observable<any> {
        return this.http.get<any>(`${this._baseURL}get_all_users_by_rank`).pipe(
            map((res) => {
                if (res['data'])
                    return res['data'];
                else
                    return null;
            }),
            catchError(this.handleError));
    }




    Delete(): Observable<any> {
        return this.http.get<any>(`${this._baseURL}get_all_users_by_rank`).pipe(
            map((res) => {
                if (res['data'])
                    return res['data'];
                else
                    return null;
            }),
            catchError(this.handleError));
    }
}
