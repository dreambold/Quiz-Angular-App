import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { map } from "rxjs/operators";
import { uRegister } from "./userRegister.model";
import { AppConstants } from '../../constants';

@Injectable()
export class userService {
  formData: uRegister;
  _baseURL: string;
  constructor(private http: HttpClient) {
      this._baseURL = AppConstants.baseURL;
  }

  userRegister(url: string, body: any) {
    return this.http.post(`${this._baseURL}${url}`, body);
  }

  postEmployee(formData: uRegister) {
    return this.http.post(this._baseURL + "register_user", formData);
  }
}
