export interface uRegister {
    obtainedMarks: number,
    totalMarks: number,
}