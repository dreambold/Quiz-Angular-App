import { Injectable } from "@angular/core";
import { promise } from "protractor";
import { Iplayer } from "./player.model";
import { Observable } from "rxjs/internal/Observable";
import {
  HttpParams,
  HttpClient,
  HttpErrorResponse
} from "@angular/common/http";
import { User } from "src/app/services/user";
import { map, catchError } from "rxjs/operators";
import { throwError } from "rxjs/internal/observable/throwError";
import { AppConstants } from '../../constants';

@Injectable()
export class playerService {
  user: User;
  results: any[];
  _baseURL: string;
  constructor(private http: HttpClient) {
      this._baseURL = AppConstants.baseURL;
  }

  getPlayersResult() {
    return this.http.get<any>(`${this._baseURL}get-user-results`).pipe(
      map(res => {
        return res;
      })
    );
  }
  getAllResults(): Observable<any[]> {
    return this.http.get(`${this._baseURL}get-user-results`).pipe(
      map(res => {
        this.results = res["data"];
        return this.results;
      }),
      catchError(this.handleError)
    );
  }
  private handleError(error: HttpErrorResponse) {
    console.log(error);

    // return an observable with a user friendly message
    return throwError("Error! something went wrong.");
  }
}
