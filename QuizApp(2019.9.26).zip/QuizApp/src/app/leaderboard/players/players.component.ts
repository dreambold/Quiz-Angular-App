import { Component, OnInit, Input } from "@angular/core";
import { Iplayer } from "./player.model";
import { Router } from "@angular/router";
import { playerService } from "./player.service";
import { authService } from "src/app/auth.service";

@Component({
  selector: "app-players",
  templateUrl: "./players.component.html",
  styleUrls: ["./players.component.css"]
})
export class PlayersComponent implements OnInit {
  players: Iplayer[];
  constructor(
    private router: Router,
    private pService: playerService,
    private _authService: authService
  ) {
    this.players = [];
  }

  ngOnInit() {
    this.pService.getPlayersResult().subscribe(data => (this.players = data));
  }
  onClick(event: Event): void {
    event.preventDefault(); // Prevents browser following the link
    this.router.navigate(["/Register"]);
  }
  LBoard(event: Event): void {
    this._authService.login();
    event.preventDefault(); // Prevents browser following the link
    this.router.navigate(["/dashboard"]);
  }
}
