
export class Question {
  constructor(
    heading: string,
    subHeading: string,
    options: Option[]) {

    }
}

class Option {
  constructor(
    oText: string,
    gradeId: number,
    rText: string,
    rmText: string){}
}