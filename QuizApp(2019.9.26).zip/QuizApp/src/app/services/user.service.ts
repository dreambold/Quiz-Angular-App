import { Injectable } from "@angular/core";
import {
  HttpClient,
  HttpErrorResponse,
  HttpParams
} from "@angular/common/http";

import { Observable, throwError } from "rxjs";
import { map, catchError } from "rxjs/operators";

import { User } from "./user";
import { AppConstants } from "../constants";

@Injectable({
  providedIn: "root"
})
export class UserService {
  user: User;
  results: any[];
  _baseURL: string;
  constructor(private http: HttpClient) {
    this._baseURL = AppConstants.baseURL;
    this.results = [];
  }

  login(username: string, password: string): Observable<boolean> {
    let params = new HttpParams().set("username", username);
    params = params.set("password", password);
    return this.http.get(`${this._baseURL}login`, { params: params }).pipe(
      map(res => {
        if (res["data"]) return true;
        else return false;
      }),
      catchError(this.handleError)
    );
  }

  getUser(username: string): Observable<any> {
    let params = new HttpParams().set("username", username);
    return this.http.get(`${this._baseURL}get-user`, { params: params }).pipe(
      map(res => {
        console.log("getUser(username: string) in user.service.ts ==>", res);

        if (res["data"]) return res["data"];
        else return null;
      }),
      catchError(this.handleError)
    );
  }

  store(user: any): Observable<any> {
    return this.http.post(`${this._baseURL}store-user`, { data: user }).pipe(
      map(res => {
        if (res["data"]) return res["data"];
        else return null;
      }),
      catchError(this.handleError)
    );
  }

  saveResult(result: any): Observable<any> {
    return this.http.post(`${this._baseURL}save-result`, { data: result }).pipe(
      map(res => {
        if (res["data"]) return res["data"];
        else return null;
      }),
      catchError(this.handleError)
    );
  }

  getResult(userId: number): Observable<any> {
    let params = new HttpParams().set("userId", userId.toString());
    return this.http.get(`${this._baseURL}get-result`, { params: params }).pipe(
      map(res => {
        if (res["data"]) return res["data"];
        else return null;
      }),
      catchError(this.handleError)
    );
  }

  getAllResults(userId: number): Observable<any[]> {
    let params = new HttpParams().set("userId", userId.toString());
    return this.http
      .get(`${this._baseURL}get-user-results`, { params: params })
      .pipe(
        map(res => {
          this.results = res["data"];
          return this.results;
        }),
        catchError(this.handleError)
      );
  }

  private handleError(error: HttpErrorResponse) {
    console.log(error);

    // return an observable with a user friendly message
    return throwError("Error! something went wrong.");
  }

  createUser(userdata: any): Observable<any> {
    return this.http
      .post(`${this._baseURL}register_user`, { data: userdata })
      .pipe(
        map(res => {
          if (res["data"]) return res["data"];
          else return null;
        }),
        catchError(this.handleError)
      );
  }
}
