import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { QuizComponent } from './quiz/quiz.component';
import { AdminComponent } from './admin/admin.component';
import { AuthGuard } from './auth-guard.service';
import { LogoutComponent } from './logout/logout.component';
import { UserRegisterComponent } from './admin/user-register/user-register.component';
import { DashboardComponent } from './admin/dashboard/dashboard.component';
import { PlayersComponent } from './admin/leaderboard/players/players.component';
import { UsersComponent } from './admin/users/users.component';
import { LeaderboardComponent } from './leaderboard/leaderboard.component';


const routes: Routes = [
 { path: '', redirectTo: '/quiz',pathMatch: 'full' },
  { path: 'quiz', component: QuizComponent },
  { path: 'admin', component: AdminComponent, },
  { path: 'logout', component: LogoutComponent},
  { path: 'Register',canActivate: [ AuthGuard], component: UserRegisterComponent},
  {path: 'dashboard',canActivate: [ AuthGuard], component: DashboardComponent },
  {path: 'player',canActivate: [ AuthGuard], component: PlayersComponent},
  {path: 'users', canActivate: [ AuthGuard],component: UsersComponent},
  {path: 'leaderboard', component: LeaderboardComponent},
  {path: 'newquiz', component: QuizComponent},
  {path: 'user',canActivate: [ AuthGuard], component: UsersComponent}
];
// canActivate: [ AuthGuard],
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
